# 📱 Configurador APN Elite

O **Configurador APN Elite** é uma ferramenta técnica profissional desenvolvida para auxiliar técnicos de telecomunicações e usuários finais na configuração de pontos de acesso (APN), busca de rede e suporte especializado para operadoras móveis.

## 🚀 Funcionalidades Principais

- **Configuração de APN:** Guias passo a passo para as principais operadoras (Vivo, Tim, Claro, Americanet, etc.).
- **Busca de Rede:** Instruções detalhadas para seleção manual de rede em diversos modelos de aparelhos.
- **Discagem DDD:** Consulta rápida de formatos de discagem interurbana por operadora.
- **Suporte IA (Gemini 3):** Assistente inteligente integrado com Google Search para resolver problemas técnicos complexos em tempo real.
- **Interface Customizável:** Ajuste de cores, fontes, bordas e sombras para uma experiência personalizada.
- **Modo Escuro & Neon:** Temas visuais modernos para diferentes ambientes de trabalho.

## 🛠️ Tecnologias Utilizadas

- **React 19 + Vite:** Performance e desenvolvimento ágil.
- **Tailwind CSS:** Estilização moderna e responsiva.
- **Framer Motion:** Animações fluidas e interativas.
- **Google Gemini AI SDK:** Inteligência artificial de última geração para suporte técnico.
- **Lucide React:** Conjunto de ícones profissionais.

## 📦 Como Rodar o Projeto Localmente

1. **Clone o repositório:**
   ```bash
   git clone https://github.com/SEU_USUARIO/configurador-apn-elite.git
   cd configurador-apn-elite
   ```

2. **Instale as dependências:**
   ```bash
   npm install
   ```

3. **Configure a Chave de API:**
   Crie um arquivo `.env` na raiz do projeto e adicione sua chave do Google AI Studio:
   ```env
   VITE_GEMINI_API_KEY=sua_chave_aqui
   ```

4. **Inicie o servidor de desenvolvimento:**
   ```bash
   npm run dev
   ```

## 🌐 Deploy

Este projeto é compatível com plataformas como **Vercel**, **Netlify** e **Cloud Run**. Ao fazer o deploy, lembre-se de configurar a variável de ambiente `VITE_GEMINI_API_KEY` no painel administrativo da plataforma escolhida.

---
Desenvolvido com foco em eficiência e produtividade técnica.
