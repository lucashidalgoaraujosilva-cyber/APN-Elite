/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { GoogleGenAI } from "@google/genai";
import { 
  Palette, 
  Moon, 
  Sun, 
  Check, 
  Copy, 
  Phone, 
  Settings2,
  ChevronDown,
  Smartphone,
  Sparkles,
  Send,
  Loader2,
  Trash2,
  Type,
  Layers,
  Box
} from 'lucide-react';
import { CARRIERS, BRANDS } from './constants';

export default function App() {
  // Theme State
  const [hue, setHue] = useState(220);
  const [isDark, setIsDark] = useState(false);
  const [isNeon, setIsNeon] = useState(false);
  const [radius, setRadius] = useState(20);
  const [glassOpacity, setGlassOpacity] = useState(0.85);
  const [fontFamily, setFontFamily] = useState('sans');
  const [borderWidth, setBorderWidth] = useState(2);
  const [shadowIntensity, setShadowIntensity] = useState(1);
  const [showSettings, setShowSettings] = useState(false);

  // App State
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedCarrier, setSelectedCarrier] = useState<string | null>(null);
  const [selectedBrand, setSelectedBrand] = useState<string>('');
  const [selectedModel, setSelectedModel] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'apn' | 'manual' | 'dial' | 'ai'>('apn');
  const [toast, setToast] = useState(false);

  // AI State
  const [aiQuestion, setAiQuestion] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  const resultRef = useRef<HTMLDivElement>(null);

  // Apply Theme Variables
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--hue', hue.toString());
    root.style.setProperty('--radius', `${radius}px`);
    root.style.setProperty('--glass-opacity', glassOpacity.toString());
    root.style.setProperty('--border-w', `${borderWidth}px`);
    root.style.setProperty('--shadow-mult', shadowIntensity.toString());
    
    const fontMap: Record<string, string> = {
      sans: '"Outfit", ui-sans-serif, system-ui, sans-serif',
      serif: 'ui-serif, Georgia, Cambria, "Times New Roman", Times, serif',
      mono: '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace'
    };
    root.style.setProperty('--font-main', fontMap[fontFamily] || fontMap.sans);
    
    if (isDark) {
      document.body.classList.add('dark');
    } else {
      document.body.classList.remove('dark');
    }

    if (isNeon) {
      document.body.classList.add('neon-active');
    } else {
      document.body.classList.remove('neon-active');
    }
  }, [hue, isDark, isNeon, radius, glassOpacity, fontFamily, borderWidth, shadowIntensity]);

  const handleCarrierSelect = useCallback((key: string) => {
    setSelectedCarrier(key);
    setHue(CARRIERS[key].color);
    if (currentStep < 2) setCurrentStep(2);
  }, [currentStep]);

  const handleBrandSelect = useCallback((brand: string) => {
    setSelectedBrand(brand);
    setSelectedModel('');
    if (currentStep < 3) setCurrentStep(3);
  }, [currentStep]);

  const handleModelSelect = useCallback((model: string) => {
    setSelectedModel(model);
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  }, []);

  const handleAiClear = () => {
    setAiQuestion('');
    setAiResponse('');
  };

  const handleAiAsk = async () => {
    if (!aiQuestion.trim()) return;
    
    setIsAiLoading(true);
    setAiResponse('');
    
    try {
      const apiKey = import.meta.env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
      const ai = new GoogleGenAI({ apiKey });
      const context = `O usuário está usando a operadora ${selectedCarrier || 'não selecionada'} e o aparelho ${selectedBrand || ''} ${selectedModel || ''}.`;
      const prompt = `${context}\n\nPergunta do usuário: ${aiQuestion}\n\nPor favor, pesquise e responda como resolver o problema com um passo a passo detalhado. Use markdown para formatar a resposta.`;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
        },
      });
      
      setAiResponse(response.text || 'Não foi possível obter uma resposta no momento.');
    } catch (error) {
      console.error('Erro na IA:', error);
      setAiResponse('Ocorreu um erro ao processar sua pergunta. Por favor, tente novamente.');
    } finally {
      setIsAiLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setToast(true);
    setTimeout(() => setToast(false), 2000);
  };

  const renderTimeline = (items: string[]) => {
    return items.map((item, index) => (
      <div key={index} className="timeline-step">
        <div className="step-num">{index + 1}</div>
        <div className="step-txt" dangerouslySetInnerHTML={{ __html: item }} />
      </div>
    ));
  };

  return (
    <div className="flex justify-center p-5 min-h-screen">
      <div className="app-shell">
        <header className="flex justify-between items-start mb-10 border-b border-[var(--border)] pb-6">
          <div className="brand">
            <h1 className="m-0 text-2xl font-extrabold tracking-tight bg-gradient-to-br from-[var(--text-main)] to-[var(--primary)] bg-clip-text text-transparent transition-all duration-500">
              Configurador APN
            </h1>
            <p className="mt-1 text-sm text-[var(--text-muted)] font-medium">Portal Técnico Profissional</p>
          </div>
          <div className="flex gap-2.5">
            <button 
              className="icon-btn" 
              onClick={() => setShowSettings(!showSettings)}
              title="Aparência"
            >
              <Palette size={20} />
            </button>
            <button 
              className="icon-btn" 
              onClick={() => setIsDark(!isDark)}
              title="Modo Escuro"
            >
              {isDark ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>

          <AnimatePresence>
            {showSettings && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute top-24 right-10 bg-[var(--surface)] p-5 rounded-[var(--radius)] border border-[var(--border)] shadow-[var(--shadow-hover)] z-50 flex flex-col gap-4 w-64 backdrop-blur-3xl"
              >
                <span className="text-[10px] font-extrabold text-[var(--text-muted)] uppercase tracking-wider">Cor Principal</span>
                <div className="grid grid-cols-5 gap-2">
                  {[220, 265, 25, 150, 350].map((h) => (
                    <div 
                      key={h}
                      className="w-7.5 h-7.5 rounded-full cursor-pointer border-2 border-[var(--surface)] shadow-[0_0_0_1px_var(--border)] transition-transform hover:scale-125"
                      style={{ background: `hsl(${h}, 95%, 50%)` }}
                      onClick={() => setHue(h)}
                    />
                  ))}
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-extrabold text-[var(--text-muted)] uppercase tracking-wider">Efeito Neon</span>
                  <div 
                    className={`w-10 h-5.5 rounded-full relative cursor-pointer transition-all duration-300 ${isNeon ? 'bg-[var(--primary)]' : 'bg-[var(--border)]'}`}
                    onClick={() => setIsNeon(!isNeon)}
                  >
                    <div className={`absolute top-0.5 left-0.5 w-4.5 h-4.5 bg-white rounded-full transition-all duration-300 shadow-sm ${isNeon ? 'translate-x-4.5' : ''}`} />
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <span className="text-[10px] font-extrabold text-[var(--text-muted)] uppercase tracking-wider">Arredondamento</span>
                  <input 
                    type="range" 
                    min="0" 
                    max="30" 
                    value={radius} 
                    onChange={(e) => setRadius(parseInt(e.target.value))}
                    className="accent-[var(--primary)]"
                  />
                </div>

                <div className="flex flex-col gap-2">
                  <span className="text-[10px] font-extrabold text-[var(--text-muted)] uppercase tracking-wider">Transparência</span>
                  <input 
                    type="range" 
                    min="0.5" 
                    max="1" 
                    step="0.05" 
                    value={glassOpacity} 
                    onChange={(e) => setGlassOpacity(parseFloat(e.target.value))}
                    className="accent-[var(--primary)]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1.5">
                    <span className="text-[9px] font-bold text-[var(--text-muted)] uppercase flex items-center gap-1"><Type size={10} /> Fonte</span>
                    <select 
                      value={fontFamily} 
                      onChange={(e) => setFontFamily(e.target.value)}
                      className="text-[10px] p-1.5 rounded-lg bg-[var(--bg-body)] border border-[var(--border)] text-[var(--text-main)]"
                    >
                      <option value="sans">Sans</option>
                      <option value="serif">Serif</option>
                      <option value="mono">Mono</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <span className="text-[9px] font-bold text-[var(--text-muted)] uppercase flex items-center gap-1"><Layers size={10} /> Borda</span>
                    <select 
                      value={borderWidth} 
                      onChange={(e) => setBorderWidth(parseInt(e.target.value))}
                      className="text-[10px] p-1.5 rounded-lg bg-[var(--bg-body)] border border-[var(--border)] text-[var(--text-main)]"
                    >
                      <option value="1">Fina</option>
                      <option value="2">Normal</option>
                      <option value="4">Larga</option>
                    </select>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <span className="text-[9px] font-bold text-[var(--text-muted)] uppercase flex items-center gap-1"><Box size={10} /> Intensidade Sombra</span>
                  <input 
                    type="range" 
                    min="0" 
                    max="2" 
                    step="0.1" 
                    value={shadowIntensity} 
                    onChange={(e) => setShadowIntensity(parseFloat(e.target.value))}
                    className="accent-[var(--primary)]"
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </header>

        <div className="flex justify-between items-center relative mb-11 px-2.5">
          <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-[var(--border)] -translate-y-1/2 z-0" />
          {[1, 2, 3].map((step) => (
            <div 
              key={step} 
              className={`step-node ${currentStep === step ? 'active' : ''} ${currentStep > step ? 'done' : ''}`}
            >
              {currentStep > step ? <Check size={16} /> : step}
            </div>
          ))}
        </div>

        <section className="mb-8">
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-[var(--text-muted)] mb-4 block">1. Selecione a Operadora</span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {Object.entries(CARRIERS).map(([key, carrier]) => (
              <div 
                key={key}
                className={`chip-card ${selectedCarrier === key ? 'selected' : ''}`}
                onClick={() => handleCarrierSelect(key)}
              >
                <div className="w-14 h-auto opacity-50 transition-all duration-300 group-hover:opacity-100">
                   <Smartphone size={48} className={selectedCarrier === key ? 'text-[var(--primary)]' : 'text-[var(--text-muted)]'} />
                </div>
                <span className="font-bold text-sm text-[var(--text-main)] capitalize">{key}</span>
              </div>
            ))}
          </div>
        </section>

        <motion.section 
          initial={false}
          animate={{ opacity: selectedCarrier ? 1 : 0.5, y: selectedCarrier ? 0 : 15 }}
          className={`mb-8 transition-all duration-300 ${!selectedCarrier ? 'pointer-events-none' : ''}`}
        >
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-[var(--text-muted)] mb-4 block">2. Marca do Aparelho</span>
          <div className="relative">
            <select 
              value={selectedBrand}
              onChange={(e) => handleBrandSelect(e.target.value)}
              className="w-full p-4.5 rounded-[var(--radius)] border-2 border-[var(--border)] bg-[var(--bg-body)] text-[var(--text-main)] font-medium appearance-none focus:outline-none focus:border-[var(--primary)] focus:bg-[var(--surface)] transition-all duration-300"
            >
              <option value="">Selecione...</option>
              {Object.entries(BRANDS).map(([key, brand]) => (
                <option key={key} value={key}>{brand.label}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-4.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" size={20} />
          </div>
        </motion.section>

        <motion.section 
          initial={false}
          animate={{ opacity: selectedBrand ? 1 : 0.5, y: selectedBrand ? 0 : 15 }}
          className={`mb-8 transition-all duration-300 ${!selectedBrand ? 'pointer-events-none' : ''}`}
        >
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-[var(--text-muted)] mb-4 block">3. Linha do Modelo</span>
          <div className="relative">
            <select 
              value={selectedModel}
              onChange={(e) => handleModelSelect(e.target.value)}
              className="w-full p-4.5 rounded-[var(--radius)] border-2 border-[var(--border)] bg-[var(--bg-body)] text-[var(--text-main)] font-medium appearance-none focus:outline-none focus:border-[var(--primary)] focus:bg-[var(--surface)] transition-all duration-300"
            >
              <option value="">Selecione...</option>
              {selectedBrand && BRANDS[selectedBrand].lines.map((line) => (
                <option key={line} value={line}>{line}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-4.5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" size={20} />
          </div>
        </motion.section>

        {selectedModel && selectedCarrier && (
          <motion.div 
            ref={resultRef}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-10"
          >
            <div className="flex gap-1.5 bg-[var(--bg-body)] p-1.5 rounded-[var(--radius)] mb-8 overflow-x-auto">
              {(['apn', 'manual', 'dial', 'ai'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 py-3 px-2 rounded-xl font-semibold text-xs transition-all duration-300 min-w-[100px] flex items-center justify-center gap-2 ${activeTab === tab ? 'bg-[var(--surface)] text-[var(--primary)] shadow-sm' : 'text-[var(--text-muted)]'}`}
                >
                  {tab === 'apn' && 'Configurar APN'}
                  {tab === 'manual' && 'Busca de Rede'}
                  {tab === 'dial' && 'Discagem DDD'}
                  {tab === 'ai' && (
                    <>
                      <Sparkles size={14} />
                      Suporte IA
                    </>
                  )}
                </button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              {activeTab === 'apn' && (
                <motion.div 
                  key="apn"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                >
                  <div className="data-card apn">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-[10px] font-extrabold text-[var(--text-muted)] uppercase tracking-wider">Nome de Perfil</span>
                      <div className="val-pill">
                        <span>{CARRIERS[selectedCarrier].name}</span>
                        <Copy 
                          size={18} 
                          className="text-[var(--primary)] opacity-60 cursor-pointer hover:opacity-100 transition-opacity" 
                          onClick={() => copyToClipboard(CARRIERS[selectedCarrier].name)}
                        />
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-extrabold text-[var(--text-muted)] uppercase tracking-wider">Endereço APN</span>
                      <div className="val-pill">
                        <span>{CARRIERS[selectedCarrier].apn}</span>
                        <Copy 
                          size={18} 
                          className="text-[var(--primary)] opacity-60 cursor-pointer hover:opacity-100 transition-opacity" 
                          onClick={() => copyToClipboard(CARRIERS[selectedCarrier].apn)}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    {renderTimeline(BRANDS[selectedBrand].apn)}
                  </div>
                </motion.div>
              )}

              {activeTab === 'manual' && (
                <motion.div 
                  key="manual"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="space-y-4"
                >
                  {renderTimeline(BRANDS[selectedBrand].manual)}
                </motion.div>
              )}

              {activeTab === 'dial' && (
                <motion.div 
                  key="dial"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="dial-card"
                >
                  <div className="w-12 h-12 bg-[var(--primary)] text-white rounded-full grid place-items-center shadow-lg">
                    <Phone size={24} />
                  </div>
                  <span className="text-sm font-extrabold text-[var(--text-muted)] uppercase tracking-wider">Forma de Discagem Interurbana</span>
                  <div className="text-2xl font-extrabold text-[var(--text-main)] mt-2">
                    {CARRIERS[selectedCarrier].dial}
                  </div>
                  <p className="text-sm text-[var(--text-muted)] max-w-[80%] leading-relaxed mt-2">
                    Utilize este formato para realizar chamadas para outros estados ou DDDs diferentes do seu.
                  </p>
                </motion.div>
              )}
              {activeTab === 'ai' && (
                <motion.div 
                  key="ai"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  className="space-y-6"
                >
                  <div className="relative">
                    <textarea 
                      value={aiQuestion}
                      onChange={(e) => setAiQuestion(e.target.value)}
                      placeholder="Como posso te ajudar hoje? (ex: Meu 4G não funciona)"
                      className="w-full p-4.5 pr-24 rounded-[var(--radius)] border-[var(--border-w)] border-[var(--border)] bg-[var(--bg-body)] text-[var(--text-main)] font-medium focus:outline-none focus:border-[var(--primary)] focus:bg-[var(--surface)] transition-all duration-300 min-h-[120px] resize-none"
                    />
                    <div className="absolute right-3 bottom-3 flex gap-2">
                      {(aiQuestion || aiResponse) && (
                        <button 
                          onClick={handleAiClear}
                          className="w-10 h-10 bg-[var(--bg-body)] text-[var(--text-muted)] border border-[var(--border)] rounded-xl grid place-items-center hover:text-red-500 hover:border-red-500 transition-all"
                          title="Limpar pesquisa"
                        >
                          <Trash2 size={18} />
                        </button>
                      )}
                      <button 
                        onClick={handleAiAsk}
                        disabled={isAiLoading || !aiQuestion.trim()}
                        className="w-10 h-10 bg-[var(--primary)] text-white rounded-xl grid place-items-center shadow-lg hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
                      >
                        {isAiLoading ? <Loader2 className="animate-spin" size={20} /> : <Send size={20} />}
                      </button>
                    </div>
                  </div>

                  {aiResponse && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="data-card p-6 prose prose-slate dark:prose-invert max-w-none"
                    >
                      <div className="markdown-body">
                        <ReactMarkdown>{aiResponse}</ReactMarkdown>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </div>

      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: 50, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 50, x: '-50%' }}
            className="fixed bottom-8 left-1/2 bg-[var(--text-main)] text-[var(--surface)] px-6 py-3 rounded-full font-semibold shadow-2xl z-[100] flex items-center gap-2.5"
          >
            <Check size={18} className="text-emerald-500 stroke-[3px]" />
            <span>Copiado com sucesso!</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
